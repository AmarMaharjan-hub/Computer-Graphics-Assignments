/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classworks;
import java.awt.*;
import javax.swing.*;
/**
 *
 * @author riku
 */
public class RotationFixedPoint extends Canvas{
    public static int[][] multiply(int[][] m1, int[][]m2){
        int[][] product=new int[3][3];
        for(int i=0;i<3;i++){
            for(int j=0;j<3;j++){
                for(int k=0;k<3;k++){
                    product[i][j] += m1[i][k]*m2[k][j];
                }
            }
        }
        return product;
    }
    public static void main(String[] args){
        RotationFixedPoint m=new RotationFixedPoint();
        JFrame f=new JFrame();
        f.setSize(400,400);
        f.add(m);
        f.setVisible(true);
    }
    public void paint(Graphics g){
        setBackground(Color.WHITE);
        setForeground(Color.BLACK);
        g.drawLine(getWidth()/2,0,getWidth()/2,getHeight());
        g.drawLine(0,getHeight()/2,getWidth(),getHeight()/2);
        int xc=getWidth()/2,yc=getHeight()/2;
        int[][] obj={
            {50,100,60},
            {10,100,120},
            {1,1,1}
        };
        int[][] obj_=new int[3][3];
    }
}
